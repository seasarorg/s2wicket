CREATE TABLE message (
  name VARCHAR(255),
  date TIMESTAMP,
  message VARCHAR(255)
);